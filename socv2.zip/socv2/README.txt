                                  

         Instructions for loading & flashing  DE0-Nano_SoC board
            running the RL01/RL02 disk emulator on it

	Requirement : Up and running  FPGA-SoC_Linux on a 
                       SoC/HPS board, like the DE10-Nano

                 Reference : DE10-Nano_User_manual.pdf

Folders:

FW:	Contains the RL_EMULATOR_SoC.jic file for flashing the FW into the EPCS and
	the RL_EMULATOR_SoC.rbf for loading the FW in the FPGA.
	The .cof file are configuration files if you want to convert the .sof file
	to .jic or .rbf by yourself. 

RL:	Contains the binary runable RL-emulator file: rlemulator 

UTIL:	Contains two convertion utilities.
	dec2dsk : converts the .DEC format to .DSK format
 	dsk2dec : converts the .DSK format to .DEC format
	Note: The RL-emulator is using the .DEC format. If You want to have access
	via the SIMH CPU-emulators, you have to convert the data files to .DSK format
        and/or the other way round. In the next release, this feature will be implemented 
	inline in the RL-emulator.


SIMH:	Contains 2 runable  SIMH based emulator for the PDP-8 and PDP-11
	More details on https://github.com/simh/simh  



			     Jumper settings

DE10-Nano: The four slide switches ( page 26, User_manual ): Select 16 disk sets, 0 to F
           Button 2 and 3 : Reconfigure and Reset/Restart
Interface-board: Switch 8: init and configure a new disk set based on the slide switches.
                 Switch 7 : Force Power OK
                 Switch 6 : Debug - Mode ON/OFF
                 Switch 5 : drive typ, RL01 or RL02
                 Switch 4 - 1 : Confired RL-drives, 1=RL3,2=RL2,3=RL1,4=RL0
                                All Switch = OFF , = OFFLINE mode.


                             Getting started

The DE10-Nano board is pre-configured with the Angstrom Linux - Kernel ( DE10_Nano_LXDE).
the default installed Linux is not able to run with a EPCS configuration, see point 2)
I recommend to use the de10_nano_linux_console.img  which can be very easy installed
with disk-imager like win32diskimager. More details in the  Getting_Started_Guide.pdf.
The images and all documentation can be downloaded from www.de10-nano.terasic.com/cd

*************************************** Note ******************************************
Note: Point 3) is not working yet with the Angstrom v2014.12 - Kernel. It would be my 
favorite implementation. It was possible with DE0-Nano-Soc board via the simple command:
dd if=RL_EMULATOR.rbf of=/dev/fpga0 bs=1M  but this board is no longer available and it 
was based on another Unix, Poky 8.0 (Yocto Project 1.3 Reference Distro) 1.3 . 
Please find the support statement from  terasic at Point 3)
***************************************************************************************


 First, copy the file "socv2.zip" to the DE0-Nano-SoC board, 
 for example, using scp . unpack the zip file and navigate to folder socv2.


1) Load .sof file(NOT permanent) 

- De0-Nano-SoC DIP switch (SW10) to default configuration, see page 12 @ User_manuel
- unzip the file "socv2.zip" 
- Start Quartus Lite Version 16.1
- Make sure, your USB connection to the DE10-Nano is working.
- Follow the instruction in the DE10-Nano_User_manual at page 15  
  and load the  RL_EMULATOR_SoC.sof file.
- After download , the heartbeat LED schould be blinking.

2) Permanent (EPCS): Required: Quartus Lite Version 16.1
-  De0-Nano-SoC DIP switch (SW10) to EPCS configuration, see page 12 @ User_manuel
-  unzip the file "socv2.zip" 
-  Start Quartus Lite Version 16.1
-  Make sure, your USB connection to the DE10-Nano is working.
-  Follow the instruction in the DE10-Nano_User_manual at page 112 and flash
   the DE10-Nano board with the fil  RL_EMULATOR_SoC.jic  from folder /flash.
-  After repowering the DE10-Nano board, the heartbeat LED schould be blinking.

3) without Quartus ( per default: NOT permanent) ******* See Note************** 
   Please refere to attached file: FPGA_configure_from_HPS.jpg

   As soon as I have a workable and easier solution I will publish it 
   with an extra readme file. A note is of course very welcome.

   


            Navigate to folder RL ( /home/root/socv2/RL ) and start the ./rlemulator
            ************************************************************************


               This is open source. Details,  including all sources  at:
               https://github.com/pdp11gy/SoC-HPS-based-RL-disk-emulator 

	                 www.pdp11gy.com   info@pdp11gy.com


Some personal information:
I use also a Raspberry Pi 3 ( model B ) connected via network to the DE10-Nano board.
I use the Raspberry for development purposes with a graphical interface. I can compile
the programs like SIMH emulators and copy it to the DE10-Nano board, because it is
binary compatible. That's so great and there is still a lot of room for further additional 
applications.
