Please read pdf-Version : RL-cloner-v2_5.pdf
********************************************
********************************************




Get started , RL01/RL02 cloner/reader
-------------------------------------

Reference:
RL01/RL02 emulator manual: RL02_01-disk-emulator.pdf  at github :
https://github.com/pdp11gy/SoC-HPS-based-RL-disk-emulator
and RL-cloner-v2_5.pdf(enclosed)

Before you start:
In order to start the clonrl program, a HW change(FCO) must be made on the interface 
board. Background:
Generally: Only(!) the 40pin flat-cable has to be plugged into the RL interface 
board by 180 degrees, i.e. reversed. However, there is one exception, the Power-OK 
signal. This signal is present at PIN A as input in slave mode and as output at 
pin VV in master mode. However, the pin VV is connected to ground on the interface board.
Todo: 
Cut the ground etch to pin VV and connected the pin to +5 VCC via a resistor
about 200 Ohm. See also enclosed picture clonerl_FCO.jpg

	FPGA+PINs    	    Emulator-Mode                   Clone-Mode
                    |
	AG25=13	  B/A=	 01  Power_ok	 -|+		39  --------------
	AH26=14	  D/C=	 03  Drive-sel_0 -|+		37  Drive-Error +|-
	AH24=15	  F/E=	 05  Drive-sel_1 -|+		35  Drive-ready +|-
	AF25=16	  J/H=	 07  Write-gate  -|+		33  Sector	+|-
	--	  L/K=	 09  ---------------		31  ---------------
	AG23=17	  N/M=	 11  System-Clk  -|+		29  Status-Clk	+|-  
	--	  R/P=	 13  ---------------		27  ---------------
	AF23=18	  T/S=	 15  Write-data  -|+            25  Status-IN 	+|-
	--	  V/U=	 17  ---------------		23  ---------------
	AG24=19	  X/W=	 19  Command  	 -|+		21  Read-data   +|-
	===================================================================
	AH22=20	  Z/Y=	 21  Read-data   -|+		19  Command  	+|-
	--	 BB/AA=	 23  ---------------		17  ---------------
	AH21=21	 DD/CC=	 25  Status-IN 	 -|+		15  Write-data  +|- 
	--	 FF/EE=	 27  ---------------		13  ---------------
	AF22=25	 JJ/HH=	 29  Status-Clk	 -|+		11  System-Clk  +|-
	--	 LL/KK=	 31  ---------------		09  --------------- 
	AG20=27	 NN/MM=	 33  Sector	 -|+		07  Write-gate  +|-
	AH19=32	 RR/PP=	 35  Drive-ready -|+		05  Drive-sel_1 +|-
	AH18=34	 TT/SS=	 37  Drive-Error -|+		03  Drive-sel_0	+|-
	--	 VV/UU=	 39  ---------------  		01  Power_ok	+|-
                 |

 

Folders:

flash:	Contains the RL_EMULATOR_SoC.jic file for flashing the FW into the EPCS and
	the RL_EMULATOR_SoC.rbf for loading the FW in the FPGA.
	The .cof file are configuration files if you want to convert the .sof file
	to .jic or .rbf by yourself. 

Programs:  clonerl , rlemulator , loadrbf and  pdp11(from SIMH project).

Installation.

- copy the clonerl.zip file to the target and unzip the file there.
- Follow the example-instruction in the Get_started_v2_3.pdf manual, page 2
-	cd clonerl
-	ls
-	Get_started_v2_3.pdf  RL02_01-disk-emulator.pdf  clonerl_FCO.jpg  loadrbf  rlemulator
	README.txt            clonerl                    flash            pdp11
-	chmod 777 *
-	ln -s ./flash/RL_EMULATOR_SoC.rbf fpga_config_file.rbf
-	./loadrbf


start the program ./clonerl. Here ist the output:


       *******>  DEC RL01/RL02 Cloner/Reader <********
     SoC/HPS DE10-Nano board V.1.0-I based on FW: V.2.5
                   (c) WWW.PDP11GY.COM

              >>>>> Device Type = RL02 <<<<
              >>>>>> DEBUG-MODE = ON <<<<<<
              **** Cloning disk-drive: DL0:
              ******** preset memory ******

 Started with operating mode:  1100 0000 1010 0001


                       Drive is ready
               Drive at cylinder position: 0
           Drive positioned to cylinder position : 0

                  ****** Select Mode ******
 1=get status, 2=clone disk, 3=read one Cylinder, 4=seek-test : 1

 get drive status:  53A  = 0000 0101 0011 1010
 drive is ready

                  ****** Select Mode ******
 1=get status, 2=clone disk, 3=read one Cylinder, 4=seek-test : 3

 Cylinder-Nr.(0 to 255 ) :3

 rl_command-1: 0000 0001 1000 0101  RAM-Address:  34560
 rl_command-2: 0000 0000 0001 0101  RAM-Address:  40320
 rl_command-3: 0000 0001 1000 0001  RAM-Address:  0
 Saved data in file: RL02_cylinder-3.dsk

                  ****** Select Mode ******
 1=get status, 2=clone disk, 3=read one Cylinder, 4=seek-test : 2


Data will be saved in file: RL02_0-clone.dsk
 set_cylind_A: 0000 0000 0000 0101  cylinder: 0  RAM_Address: 0
 set_cylind_B: 0000 0000 0001 0101
 set_cylind_A: 0000 0000 1000 0101  cylinder: 1  RAM_Address: 11520
 set_cylind_B: 0000 0000 0001 0101
 set_cylind_A: 0000 0000 1000 0101  cylinder: 2  RAM_Address: 23040
 set_cylind_B: 0000 0000 0001 0101
 .
 .
 .
 .
 set_cylind_A: 0000 0000 1000 0101  cylinder: 511  RAM_Address: 5886720
 set_cylind_B: 0000 0000 0001 0101
 Saved data in file: RL02_0-clone.dsk

                 ****** Select Mode ******
 1=get status, 2=clone disk, 3=read one Cylinder, 4=seek-test : 



                          **** SIMH interface ****

root@socfpga:~/clonerl# ./pdp11
PDP-11 simulator V3.9-0
sim> set CPU 11/23 512k
Disabling CR
Disabling RK
Disabling HK
Disabling TM
sim> attach RL0 ./RL02_0-clone.dsk
sim> boot RL0

RT-11SJ  V05.04 C

.SET USR NOSWAP

.SET TT SCOPE

.SET EDIT KED

.INIT/NOQUE VM:

.


                        ------------------------------
                                 www.pdp11gy.com
                             E-Mail: info@pdp11gy.com
                       -------------------------------

