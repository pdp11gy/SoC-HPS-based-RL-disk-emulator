#!/bin/sh
#
#  Copyright (C) 2013 by Reinhard Heuberger , www.pdp11gy.com
#
echo ""
echo ""
echo "         **** load the design into memory **** " 
echo ""
echo "         1) load the sof-file...."
nios2-configure-sof ./in_RAM/RL_emulator.sof
#
echo ""
echo "         2) load the elf-file...."
nios2-download -g ./in_RAM/MAX10_DE10_RL_Emulator_V2.elf
#
echo ""
echo "                finished "
echo ""

