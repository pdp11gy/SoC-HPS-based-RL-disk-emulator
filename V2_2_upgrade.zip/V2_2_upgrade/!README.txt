
                                            DE10_SoC_RL-Emulator

      Version V2.2: Source-kit upgrade
      ********************************* 

      Replace all these files/folders in the project folder  DE10_SoC_RL-Emulator_V2


      NEW: It is now possible to load the FPGA from Linux using .rbf file.
	   Thus it is possible to start the RL emulator without Quartus software. 
               A connection with the usb blaster is also obsolete.



                    www.pdp11gy.com   info@pdp11gy.com