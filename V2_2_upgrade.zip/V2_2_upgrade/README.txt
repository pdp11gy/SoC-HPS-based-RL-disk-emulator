
                                            DE10_SoC_RL-Emulator

      Version V2.2: Source-kit upgrade
      ******************************** 

      Replace all these files/folders in the project folder  DE10_SoC_RL-Emulator_V2



                    www.pdp11gy.com   info@pdp11gy.com