

         Instructions for loading & flashing  DE0-Nano_SoC board
            running the RL01/RL02 disk emulator on it

	Requirement : Up and running  FPGA-SoC_Linux on a 
                       SoC/HPS board, like the DE10-Nano

                 Reference : DE10-Nano_User_manual.pdf

Folders:

flash:	Contains the RL_EMULATOR_SoC.jic file for flashing the FW into the EPCS and
	the RL_EMULATOR_SoC.rbf for loading the FW in the FPGA.
	The .cof file are configuration files if you want to convert the .sof file
	by yourself. 

RL:	Contains the binary runable RL-emulator file: rlemulator 

UTIL:	Contains two convertion utilities.
	dec2dsk : converts the .DEC format to .DSK format
 	dsk2dec : converts the .DSK format to .DEC format
	Note: The RL-emulator is using the .DEC format. If You want to have access
	via the SIMH CPU-emulators, you have to convert the data files to .DSK format
        and/or the other way round. In the next release, this feature will be implemented 
	inline in the RL-emulator.


SIMH:	Contains 2 runable  SIMH based emulator for the PDP-8 and PDP-11
	More details on https://github.com/simh/simh  


                             Getting started


 first, copy the file "socv1.zip" to the DE0-Nano-SoC board, 
 for example, using scp . unpack the zip file and navigate to folder flash.


1) without Quartus ( per default: NOT permanent) 

- De0-Nano-SoC DIP switch (SW10) to default configuration, see page 12 @ User_manuel
- load the Fimware image with the command: dd if=RL_EMULATOR.rbf of=/dev/fpga0  
- After loading this file, the heartbeat LED schould be blinking.
  Note: This setup is not permanent. To make it permanent, include the dd command
        in one of the FPGA-SoC-Linux startup-files or use example 2)

2) Permanent (EPCS): Required: Quartus Lite Version 16.1
-  De0-Nano-SoC DIP switch (SW10) to EPCS configuration, see page 12 @ User_manuel
-  unzip the file "socv1.zip" 
-  Start Quartus Lite Version 16.1
-  Make sure, your USB connection to the DE10-Nano is working.
-  Follow the instruction in the DE10-Nano_User_manual at page 112 and flash
   the DE10-Nano board with the fil  RL_EMULATOR_SoC.jic  from folder /flash.
-  After repowering the DE0-Nano-SoC board, the heartbeat LED schould be blinking.

    

            Navigate to folder RL ( /home/root/RL ) and start the ./rlemulator
            ******************************************************************


               This is open source. Details,  including all sources  at:
               https://github.com/pdp11gy/SoC-HPS-based-RL-disk-emulator 

	                 www.pdp11gy.com   info@pdp11gy.com